//
//  XDPay.h
//  XDPay
//
//  Created by 杜凯强 on 2017/5/27.
//  Copyright © 2017年 xd. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for XDPay.
FOUNDATION_EXPORT double XDStoreVersionNumber;

//! Project version string for XDPay.
FOUNDATION_EXPORT const unsigned char XDStoreVersionString[];

FOUNDATION_EXPORT const NSString* PayType;

// In this header, you should import all the public headers of your framework using statements like #import <XDPay/PublicHeader.h>
#import <XDStore/XDCOMStore.h>

